package com.example.anchus.maketaster1;

import android.content.Intent;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class Main6Activity extends AppCompatActivity {
    SQLiteDatabase dbh;
    TextView t1,t2;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main6);
        t1 = (TextView) findViewById(R.id.textView15);
        t2 = (TextView) findViewById(R.id.textView16);
        Intent i = getIntent();
        String name = i.getStringExtra("name");
        Toast.makeText(getApplicationContext(), name, Toast.LENGTH_SHORT).show();

dbh = openOrCreateDatabase("Recipe", MODE_PRIVATE, null);
dbh.execSQL("CREATE TABLE IF NOT EXISTS bfast4 (id Integer primary key,name varchar,description varchar);");
      Cursor c = dbh.rawQuery("SELECT * from bfast4 where name='" + name + "'", null);
        if (c.getCount() !=0) {
            c.moveToFirst();
            t1.setText(c.getString(c.getColumnIndex("description")));
            t2.setText(c.getString(c.getColumnIndex("name")));
        }

//        StringBuffer buffer = new StringBuffer();
//        while (c.moveToNext()) {
//            buffer.append("id " + c.getString(0) + "\n");
//            buffer.append("Title: " + c.getString(1) + "\n");
//            buffer.append("Recipe: " + c.getString(2) + "\n\n");
//        }
//        showMessage("Food Recepi ", buffer.toString());
//    }
//
//    public void showMessage(String title, String message){
//        AlertDialog.Builder builder = new AlertDialog.Builder(this);
//        builder.setCancelable(true);
//        builder.setTitle(title);
//        builder.setMessage(message);
//        builder.show();
//    }}


    }}

