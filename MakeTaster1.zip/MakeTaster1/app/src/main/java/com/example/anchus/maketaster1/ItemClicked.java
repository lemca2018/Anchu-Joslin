package com.example.anchus.maketaster1;

/**
 * Created by anchus on 04-04-2017.
 */
public class ItemClicked {
}
