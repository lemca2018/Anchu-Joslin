package com.example.anchus.maketaster1;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class Main4Activity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main4);

        String[] values = new String[] { "Lemon Chicken ",
                "Caprese Pasta Salad",
                "Tortilla Soup",
                "Simple Kale and Black Bean Burritos",
                "Butter Chiken",
                "Chapati",
                "Poha",
                "Noodles"
        };

        ArrayAdapter<String> itemsAdapter = new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, values);
        ListView listView = (ListView) findViewById(R.id.listView3);
        listView.setAdapter(itemsAdapter);
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Intent in = new Intent(Main4Activity.this, Main6Activity.class);

                in.putExtra("name", (String)parent.getItemAtPosition(position));
                startActivity(in);
            }
        });
    }
}
