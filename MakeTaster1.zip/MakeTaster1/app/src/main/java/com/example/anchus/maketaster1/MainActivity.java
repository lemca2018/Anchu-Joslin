package com.example.anchus.maketaster1;

import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class MainActivity extends AppCompatActivity {
Button b1,b2,b3,b4;
    private static final String MY_PREFS_NAME = "aaaa";
    SQLiteDatabase dbh;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        b1 = (Button) findViewById(R.id.button4);
        b2 = (Button) findViewById(R.id.button2);
        b3 = (Button) findViewById(R.id.button3);
        b4 = (Button) findViewById(R.id.button5);
        b1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent my = new Intent(MainActivity.this, Main2Activity.class);
                startActivity(my);
            }
        });
        b2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent my = new Intent(MainActivity.this, Main3Activity.class);
                startActivity(my);
            }
        });
        b3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent my = new Intent(MainActivity.this, Main4Activity.class);
                startActivity(my);
            }
        });
        b4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent my = new Intent(MainActivity.this, Main5Activity.class);
                startActivity(my);
            }
        });

        dbh = openOrCreateDatabase("Recipe", MODE_PRIVATE, null);


        dbh.execSQL("CREATE TABLE IF NOT EXISTS bfast4 (id Integer primary key,name varchar,description varchar);");


        Cursor c = dbh.rawQuery("select * from bfast4", null);
        if (c.getCount() == 0) {
            Toast.makeText(this, "no value"+c.getCount(), Toast.LENGTH_SHORT).show();
            insert();
        } else {
            Toast.makeText(this, "Alredy inserted", Toast.LENGTH_SHORT).show();


        }


    }


    public void insert() {

        dbh.execSQL("insert into bfast4 values(1,'Appam','Here is the recipe for making Appam using Rice Flour and Coconut Milk. Its pretty easy as you don’t have to soak rice, grate coconut or grind anything. Again the suggestion to use Rice Flour came from my dear Mom-In-Law. Later, when I discussed with some friends, even they told me the same. Well, this Appam tastes really good and is the easiest of all but for authentic Palappam or Kallappam taste, you will have to grind rice and cant use Rice Flour.')");
        dbh.execSQL("insert into bfast4 values(2,'Idly','Wash and soak urad dal 4 about 3 to 4 hours.Grind dal to make a smooth mix.Add rice flour and salt to the ground dal and mix well.Adfd a litttle water if required so that no lumps are formed. store the batter ina large vessel and keep it overnight or for 10-12 hours,so that the batter ferments.leave the batter in awarm place.once the batter is well fermented, mix the batter well and pour laddle fulls on to greased idli plates and steam using an idli maker or pressure cooker for 10-15 minutes. ')");
        dbh.execSQL("insert into bfast4 values(3,'dosa','Soak Urad dal in water for atleast 2 or 3 hours.Grind dal adding required quantity of water to form a thick paste.Mix the rice flour,salt and grinded dal to form a loose batter.You may how to add more water to get the required consistency.Keep the batter over night to ferment.Heat a non stick thava or griddle and pour one ladle full of batter and spread it as thin as possible to make thian and crisp dosas.when the edges to become crisp(3 to 4 minutes),flip it over and keeps for 2 more minutes." +
                "You can apply few drops of oil on the edges of the dosas to give it a better taste.')");
        dbh.execSQL("insert into bfast4 values(4,'Fish Curry','Here is the recipe for making Fish Curry using Rice Flour and Coconut Milk. Its pretty easy as you don’t have to soak rice, grate coconut or grind anything. Again the suggestion to use Rice Flour came from my dear Mom-In-Law. Later, when I discussed with some friends, even they told me the same. Well, this Appam tastes really good and is the easiest of all but for authentic Palappam or Kallappam taste, you will have to grind rice and cant use Rice Flour.')");
        dbh.execSQL("insert into bfast4 values(5,'Poori','In a wide bowl,take the flour.Add salt,a pinch of sugar,rava,ghee and mix well to make a crumbly mixture.Add water little by little and make the dough.Dough should not be sticky,wet or too soft like chapati dough.It should be smooth and stiff but not hard.I used around 1/3 cup plus  1- 2 tbsp of water.It may vary based on the flour u use.Keep this as reference.Initially u may feel the dough little bit hard.knead well in between ur palms for few minutes.It will become smooth and soft.Do not allow the dough to sit for long time.Start rolling.\n" +
                "Make small lemon sized balls.Dust the balls in flour and make small sized poori of palm size.Use less flour for dusting.The thickness should be medium,not too thin like chapati.If u make it thin,puris won’t puff up.Arrange the pooris in a paper or a greased plate without overlapping each other.Heat oil to deep fry.To check the right temperature of oil,put a small piece of dough.It will rise immediately at the same time it should not be browned.This is the perfect heating of oil.Immediately slide the poori and after a second,press it with a slotted ladle.It will puff up well.Flip it carefully and allow it to cook for few seconds till  the bubbles cease.Remove and lower the flame till u drop the next poori .Drain in a tissue paper.Keep the flame high and repeat the same for remaining pooris. ')");
        dbh.execSQL("insert into bfast4 values(6,'Puttu','Get the \"stars\" ready. \n" +
                "Into your dry grinder, add in the rice flour.\n" +
                "Add in the heaped half cup cooked rice.\n" +
                "And lastly, salt.\n" +
                "Close your dry grinder bowl and pulse for 20-30 seconds. That's all your perfect puttu podi without much trouble is ready for steaming.\n" +
                "So quick and easy!! \n" +
                "Now for those, you dont know how to fill this in the puttu kutti.\n" +
                " Place the \"achu\" first and spoon in 1 tbsp of coconut scrapings.\n" +
                "Now spoon in the puttu podi till it is halfway filled.\n" +
                "Then spooin in another layer of coconut and again spoon in puttu podi and lastly spoon in coconut scrapings.\n" +
                "I use my cooker to steam, this particular puttu kutti can be placed on top of the hob of cooker and steamed....you can also use this on top of \"puttu kudam\" which usually takes longer time to cook....but the best thing about steaming atop a cooker is it will be done in 3-4 min.\n" +
                "Remove from the steamer, and wait for two min  (if you unmould immediately, it might tend to break) so it is better to allow it to cool down for a min or two...and then unmould by pressing through the back side of the mould using the stem of a spatula, gently! (or you can use a \"pappada kambi\")\n')");

        Toast.makeText(this, "inserted", Toast.LENGTH_SHORT).show();


    }

    public void setFirstBoot() {
        SharedPreferences.Editor editor = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE).edit();

        editor.putInt("check", 1);
        editor.commit();
    }

    public int getFirstBoot() {
        int id=0;
        SharedPreferences prefs = getSharedPreferences(MY_PREFS_NAME, MODE_PRIVATE);
        String restoredText = prefs.getString("text", null);
        if (restoredText != null) {

            id = prefs.getInt("check", 0); //0 is the default value.

        }
        return id;
    }


    public void showMessage(String title, String message){
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setCancelable(true);
        builder.setTitle(title);
        builder.setMessage(message);
        builder.show();
    }

    }

